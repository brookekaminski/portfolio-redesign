    <footer>
        <?php include ('social.php'); ?>
            <div class="connect">
                <h3>Let's chat?</h3> <a href="mailto:hello@brookekaminski.ca">hello@brookekaminski.ca<span class="screen-reader-text">to email message</span></a> </div>
    </footer>
</div>
</div> <!-- END OF RIGHT -->
</div> <!-- END OF CONTAINER -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="scripts/script.js"></script>
</body>

</html>