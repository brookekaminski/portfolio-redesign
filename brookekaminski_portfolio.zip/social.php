<ul class="social">
    <li> 
        <a href="http://www.linkedin.com/in/brooke-kaminski" target="_blank"><i class="icon" aria-hidden="true" data-icon="&#xeaca;"></i><span class="screen-reader-text">link to linked in</span></a> 
    </li>
    <li>
        <a href="http://codepen.io/brookekaminski/" target="_blank"><i class="icon" aria-hidden="true" data-icon="&#xeae8;"></i><span class="screen-reader-text">link to code pen</span></a> 
    </li>
    <li> 
        <a href="https://github.com/brookekaminski" target="_blank"><i class="icon" aria-hidden="true" data-icon="&#xeab0;"></i><span class="screen-reader-text">link to git hub</span></a> 
    </li>
    <li>
    <a href="https://twitter.com/brookemkaminski" target="_blank"><i class="icon" aria-hidden="true" data-icon="&#xea96;"></i><span class="screen-reader-text">link to twitter</span></a> 
    </li>
</ul>