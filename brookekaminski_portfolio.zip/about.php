<?php 
$bodyClass = 'about';
$pageTitle = ' | About';
include 'header.php';

?>
   
   
          <main id="content" class="content">
   
   
   <section class="about-page">
   
    <h2>About</h2>
    
    
     <span class="underline"></span>
    
    
    <article class="about">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras leo magna, convallis non auctor sit amet, dictum in orci. Curabitur sed vehicula ipsum, at egestas lacus. In ultricies lorem quis aliquet tincidunt. Etiam accumsan odio pretium est pulvinar, vitae tincidunt tortor consequat. Nunc euismod risus vitae mauris feugiat maximus. Aliquam lacinia eros et orci consequat tempus. Quisque luctus nibh turpis, vel dapibus velit malesuada non. Cras dignissim, tortor at consequat efficitur, tellus ligula auctor metus, ut accumsan tortor ante et ipsum.  </p>
        <p>Curabitur nulla erat, porttitor eu dolor a, dignissim convallis lorem. Proin vel urna sed augue condimentum malesuada. Nulla facilisi. Morbi et nulla quis nibh gravida aliquet in vel purus. Nunc sed eros sit amet odio condimentum elementum. Mauris aliquam rhoncus eros, vitae euismod mauris. Duis a interdum nisl. Ut nibh tellus, iaculis posuere nunc non, porttitor fermentum leo. Sed nec finibus neque, at lacinia mauris. Aenean feugiat mauris ac erat aliquam pulvinar. </p>
    </article>
    
     
     <img src="images/phaeno.JPG" alt="Brooke at the Phaeno Science Center in Wolfsburg, Germany touching a Van de Graaff generator">
    


    </section>
    
</main>
    
    <?php 

include 'footer.php';

?>